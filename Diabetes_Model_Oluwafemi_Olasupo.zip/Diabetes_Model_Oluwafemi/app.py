from flask import Flask, request, render_template
import pickle
import numpy as np

# Load the trained model
with open('model.pkl', 'rb') as model_file:
    classifier = pickle.load(model_file)

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = ""  # Initializing prediction with a default value
    if request.method == 'POST':
        try:
            # Extract input parameters from the form data
            HighBP = int(request.form['HighBP'])
            HighChol = int(request.form['HighChol'])
            CholCheck = int(request.form['CholCheck'])
            BMI = float(request.form['BMI'])
            Smoker = int(request.form['Smoker'])
            Stroke = int(request.form['Stroke'])
            HeartDiseaseorAttack = int(request.form['HeartDiseaseorAttack'])
            PhysActivity = int(request.form['PhysActivity'])
            Fruits = int(request.form['Fruits'])
            Veggies = int(request.form['Veggies'])
            AnyHealthcare = int(request.form['AnyHealthcare'])
            NoDocbcCost = int(request.form['NoDocbcCost'])
            Ment_Hlth = float(request.form['Ment_Hlth'])
            Phys_Hlth = float(request.form['Phys_Hlth'])
            Education = int(request.form['Education'])

            # Creating a NumPy array with the input values
            data = np.array([[HighBP,HighChol,CholCheck,BMI,Smoker,Stroke,HeartDiseaseorAttack,PhysActivity,Fruits,Veggies,AnyHealthcare,
                              NoDocbcCost, Ment_Hlth, Phys_Hlth, Education]])

            # Make a prediction using the loaded model
            my_prediction = int(classifier.predict(data)[0])  # Ensure it's cast to int
            
            if my_prediction == 1:
                prediction = "Sorry, you have diabetes disease."
            else:
                prediction = "No need to fear! You do not have diabetes."
        except Exception as e:
            prediction = f"Prediction Error: {str(e)}"
            
    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
